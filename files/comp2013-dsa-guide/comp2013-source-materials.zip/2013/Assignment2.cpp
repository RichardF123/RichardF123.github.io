# include <iostream>
# include <cmath>
# include <iomanip>
# include <fstream>
# include <string>

 int Difference(string filename){
 	int len n;
	ifstream file;
	file.open(filename)
	file >> n; 
	int array[n] = {};
	for(int i = 0; i<n-1 ; i++){
		file >> array[i]; 
	}
	file.close();
	Merge_Sort(array,n);
	int d = a[1]-a[0];
	for(int i = 1; i < n-1; i ++){
		if (a[i+1] - a[i] < d) d = a[i+1] - a[i]
	}
	return d;
 } 
 void Merge_Sort(int a[], int s){
 	if(s=1) return;
 	int b[s/2];
 	int c[s-s/2];
 	for(int i = 0; i < s/2; i++){
 		b[i] = a[i];
	 }
	 for (int j = s/2; j < s; j++){
	 	c[i-s/2] = a[i];
	 }
	 Merge_Sort(b,s/2);
	 Merge_Sory(c,s-s/2);
	 int i = 0, j = 0, k = 0;
	 while(i < s && j < s/2 && k < s-s/2){
	 	if(b[j]<c[k]){
	 		a[i] = b[j];
	 		i++;
	 		j++;
		 }
		else{
			a[i] = c[k];
			i++;
			k++;
		}
	 }
	 while(i<s && j = s/2){
	 	a[i] = c[k];
	 	k++;
	 	i++;
	 }
 }
 
 int main(){
 	string filename;
 	std::cin >> filename;
 	return Difference(filename);
 }
